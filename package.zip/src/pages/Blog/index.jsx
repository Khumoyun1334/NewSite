import React from 'react'
import BlogC from '../../Components/BlogC'
import Boshqa2 from '../../Components/Boshqa2'

function Blog() {
  return (
    <div>
      <div>
        <BlogC/>
        <Boshqa2/>
      </div>
    </div>
  )
}

export default Blog