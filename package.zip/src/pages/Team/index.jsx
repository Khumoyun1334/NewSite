import React from 'react'
import TeamC from '../../Components/TeamC'
import TeamComponent from '../../Components/TeamComponetn'
import Pushti from '../../Components/Pushti'

function Team() {
  return (
    <div>
      <TeamC/>
      <TeamComponent/>
      <Pushti/>
    </div>
  )
}

export default Team