import React from 'react'
import ServiceC from '../../Components/ServiceC'
import OurService from '../../Components/OurService'
import Pushti from '../../Components/Pushti'

function Service() {
  return (
    <div>
      <div>
        <ServiceC/>

        <OurService/>

        <Pushti/>
      </div>
    </div>
  )
}

export default Service