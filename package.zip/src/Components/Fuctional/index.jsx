import React from 'react'

function Fuctoinal() {
    return (
        <div>
            <div className='cards'>
                <div className="div">
                    <div className="imgs">
                        <div className="viths">
                            <div>
                                <h2 className='text-center'>Aquistion Plan</h2>
                                <p>Busisness Planning</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="div">
                    <div className="div">
                        <div className="images n1">
                            <div className="viths">
                                <div>
                                    <h2 className='text-center'>Aquistion Plan</h2>
                                    <p>Busisness Planning</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="div">
                        <div className="images n2">
                            <div className="viths">
                                <div>
                                    <h2 className='text-center'>Aquistion Plan</h2>
                                    <p>Busisness Planning</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="div">
                        <div className="images n3">
                            <div className="viths">
                                <div>
                                    <h2 className='text-center'>Aquistion Plan</h2>
                                    <p>Busisness Planning</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="div">
                        <div className="images n4">
                            <div className="viths">
                                <div>
                                    <h2 className='text-center'>Aquistion Plan</h2>
                                    <p>Busisness Planning</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Fuctoinal