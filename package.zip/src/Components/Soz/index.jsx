import React from 'react'

function Soz() {
    return (
        <div className='px-[190px] py-16'>
            <p className='font-medium text-[30px]  font-serif'>Our Finished Projects</p>
            <p className='text-[18px] mt-6 font-sans text-[#888888]'>Pallamco laboris nisi ut aliquip ex ea commodo <br /> consequat.</p>
        </div>
    )
}

export default Soz